char str1[10];
char str2[]="abcdefghijklmn";
strcpy(str1,str2);
