def legacy
redirect_to(params.update(action:'main'))
end
