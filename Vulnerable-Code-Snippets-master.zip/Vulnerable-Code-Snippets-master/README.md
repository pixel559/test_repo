# Vulnerable-Code-Snippets

A collection of vulnerable code snippets taken form around the internet. Snippets taken from various blog posts, books, resources etc. No Copyright Infringement Intended
