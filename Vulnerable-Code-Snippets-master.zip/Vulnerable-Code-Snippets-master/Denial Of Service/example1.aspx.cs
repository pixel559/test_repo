Private Sub cmdRunNotePad_Click()
Dim str As String
MyVar = window.Text()
Sleep myVar+1
dblNotePadID = Sleep(myVar)
End Sub
