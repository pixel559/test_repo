
var password = 'mysecretpass'; 

const fooPassword = 'mysecretpass'; 

